﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AirLineTuto
{
    public partial class Ticket : Form
    {
        public Ticket()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=AirlineDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        private void fillPassenger()
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select PassId from PassengerTbl", conn);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("PassId", typeof(int));
            dt.Load(rdr);
           // DataTable.Load automatically advances the reader to the next result set dt.Load(reader); 
            Passid.ValueMember = "PassId";
            Passid.DataSource = dt;
            conn.Close();

        }
        private void fillFlightFcode()
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select Fcode from FlightTbl", conn);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("Fcode", typeof(string));
            dt.Load(rdr);
            FCode.ValueMember = "Fcode";
            FCode.DataSource = dt;
            conn.Close();

        }
        private void Viewdata()
        {
            conn.Open();
            string query = "select * from TicketTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            TicketGridView1.DataSource = ds.Tables[0];
            conn.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Home ob = new Home();
            ob.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Tid.Text = "";
            Passname.Text = "";
            Passport.Text = "";
            Passnat.Text = "";
            Passgen.Text = "";
            Amt.Text = "";
        }
        string pname, ppass,  pnat, pgend;

        private void button1_Click(object sender, EventArgs e)
        {
            if (Tid.Text == "" || FCode.Text == "" || Passid.Text == "" || Passname.Text == "" || Passport.Text == "" || Passnat.Text == "" || Passgen.Text == ""||Amt.Text=="")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "insert into TicketTbl values("+Tid.Text +",'"+FCode.SelectedValue.ToString()+"',"+ Passid.SelectedValue.ToString()+",'"+ Passname.Text+"','"+Passport.Text+"','"+ Passnat.Text + "','" + Passgen.Text + "'," + Amt.Text + ")";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Ticket Booked Successfully");
                    conn.Close();
                    Viewdata();
                }
                catch (Exception ob)
                {
                    MessageBox.Show(ob.Message);
                }



            }
        }

        private void fetchPassenger()
        {
            conn.Open();
            string query = "select * from PassengerTbl where PassId=" + Passid.SelectedValue.ToString() + ";";
            SqlCommand cmd = new SqlCommand(query, conn);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach(DataRow dr in dt.Rows)
            {
                pname = dr["PassName"].ToString();
                ppass = dr["Passport"].ToString();
                pnat = dr["PassNat"].ToString();
                pgend = dr["PassGend"].ToString();
                Passname.Text = pname;
                Passport.Text = ppass;
                Passnat.Text = pnat;
                Passgen.Text = pgend;


            }

            conn.Close();
        }

        private void Ticket_Load(object sender, EventArgs e)
        {
            fillPassenger();
            fillFlightFcode();
            Viewdata();
        }

        private void Passid_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fetchPassenger();
        }
    }
}
