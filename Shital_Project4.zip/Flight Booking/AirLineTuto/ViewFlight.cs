﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AirLineTuto
{
    public partial class ViewFlight : Form
    {
        public ViewFlight()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=AirlineDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

        private void button4_Click(object sender, EventArgs e)
        {
            FlightTbl ob = new FlightTbl();
            ob.Show();
            this.Hide();
        }
        private void Viewdata()
        {
            conn.Open();
            string query = "select * from FlightTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            ViewGrid.DataSource = ds.Tables[0];
            conn.Close();
        }

        private void ViewFlight_Load(object sender, EventArgs e)
        {
            Viewdata();

        }

     

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FCode.Text = "";
            FSrc.Text = "";
            FDest.Text = "";
            FDate.Text = "";
            Seatnum.Text = "";
        }

        private void ViewGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            FCode.Text = ViewGrid.SelectedRows[0].Cells[0].Value.ToString();
            FSrc.SelectedItem = ViewGrid.SelectedRows[0].Cells[1].Value.ToString();
           
            FDest.SelectedItem = ViewGrid.SelectedRows[0].Cells[2].Value.ToString();
            Seatnum.Text = ViewGrid.SelectedRows[0].Cells[4].Value.ToString();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (FCode.Text == "" || FSrc.Text == "" || FDate.Text == "" || FDest.Text == "" || Seatnum.Text == "")
            {
                MessageBox.Show("Missing Information");

            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "update FlightTbl set Fsrc='" + FSrc.SelectedItem.ToString() + "',FDest='" + FDest.SelectedItem.ToString() + "',FDate='" + FDate.Value.ToString() + "',FCap=" + Seatnum.Text + "where Fcode='" + FCode.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("update Successfully");
                    conn.Close();
                    Viewdata();
                }
                catch (Exception ob)
                {
                    MessageBox.Show(ob.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (FCode.Text == "")
            {
                MessageBox.Show("Enter the Flight to Delete");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "delete from FlightTbl where Fcode='" + FCode.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(" Flight Delete Successfully");
                    conn.Close();
                    Viewdata();

                }
                catch (Exception ob)
                {
                    MessageBox.Show(ob.Message);
                }
            }
        }
    }
}
