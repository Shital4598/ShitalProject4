﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AirLineTuto
{
    public partial class Cancellation : Form
    {
        public Cancellation()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=AirlineDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        private void fillTicketid()
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select TId from TicketTbl", conn);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("TId", typeof(int));
            dt.Load(rdr);
            Tidtxt.ValueMember = "TId";
            Tidtxt.DataSource = dt;
            conn.Close();

        }
        private void fetchFlightCode()
        {
            conn.Open();
            string query = "select * from TicketTbl where TId=" + Tidtxt.SelectedValue.ToString() + ";";
            SqlCommand cmd = new SqlCommand(query, conn);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                Fcode.Text = dr["FCode"].ToString();
          
            }

            conn.Close();
        }

        private void Cancellation_Load(object sender, EventArgs e)
        {
            fillTicketid();
            Viewdata();

        }

        private void Tidtxt_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fetchFlightCode();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Home ob = new Home();
            ob.Show();
            this.Hide();
        }
        private void DeleteTicket()
        {

           
                try
                {
                    conn.Open();
                    string query = "delete from TicketTbl where TId=" + Tidtxt.SelectedValue.ToString()+ ";";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(" Ticket Delete Successfully");
                    conn.Close();
                    Viewdata();

                }
                catch (Exception ob)
                {
                    MessageBox.Show(ob.Message);
                }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Cancelid.Text == "" || Fcode.Text == "" )
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "insert into CancelTbl values(" + Cancelid.Text + "," + Tidtxt.SelectedValue.ToString() + ",'" + Fcode.Text + "','" + Date.Value.Date + "');";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cancel Successfully");
                    conn.Close();
                    Viewdata();
                    DeleteTicket();
                }
                catch (Exception ob)
                {
                    MessageBox.Show(ob.Message);
                }
               



            }
        }
        private void Viewdata()
        {
            conn.Open();
            string query = "select * from CancelTbl";
            SqlDataAdapter da = new SqlDataAdapter(query, conn);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            conn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Cancelid.Text = "";
            Fcode.Text = "";


        }
    }
}
