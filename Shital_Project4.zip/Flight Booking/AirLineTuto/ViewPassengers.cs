﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AirLineTuto
{
    public partial class ViewPassengers : Form
    {
        public ViewPassengers()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=AirlineDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

        private void button4_Click(object sender, EventArgs e)
        {
           AddPassenger ob = new AddPassenger();
            ob.Show();
            this.Hide();
        }
        private void Viewdata()
        {
            conn.Open();
            string query = "select * from PassengerTbl";
            SqlDataAdapter da = new SqlDataAdapter(query,conn);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            DataSet ds = new DataSet();
            da.Fill(ds);
            ViewPassenger.DataSource = ds.Tables[0];
            conn.Close();
        }
        private void ViewPassengers_Load(object sender, EventArgs e)
        {
            Viewdata();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            PassId.Text = "";
            PassName.Text = "";
            PassNum.Text = "";
            PassAdd.Text = "";
            PassNat.Text = "";
            PassGend.Text = "";
            PassPh.Text = "";

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(PassId.Text=="")
            {
                MessageBox.Show("Enter the Passenger Id to Delete");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "delete from PassengerTbl where PassId=" + PassId.Text + ";";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Delete Successfully");
                    conn.Close();
                    Viewdata();

                }
                catch(Exception ob)
                {
                    MessageBox.Show(ob.Message);
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(PassId.Text==""||PassName.Text==""||PassNum.Text==""|| PassAdd.Text == "" || PassNat.Text == "" || PassGend.Text == "" || PassPh.Text == "")
            {
                MessageBox.Show("Missing Information");

            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "update PassengerTbl set PassName='" + PassName.Text + "',Passport='" + PassNum.Text + "',PassAd='" + PassAdd.Text + "',PassNat='" + PassNat.SelectedItem.ToString() + "',PassGend='" + PassGend.SelectedItem.ToString() + "',PassPhone='" + PassPh.Text + "'where PassId=" + PassId.Text + ";";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("update Successfully");
                    conn.Close();
                    Viewdata();
                }
                catch(Exception ob)
                {
                    MessageBox.Show(ob.Message);
                }
            }
        }

      

        private void ViewPassenger_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            PassId.Text = ViewPassenger.SelectedRows[0].Cells[0].Value.ToString();
            PassName.Text = ViewPassenger.SelectedRows[0].Cells[1].Value.ToString();
            PassNum.Text = ViewPassenger.SelectedRows[0].Cells[2].Value.ToString();
            PassAdd.Text = ViewPassenger.SelectedRows[0].Cells[3].Value.ToString();
            PassNat.SelectedItem = ViewPassenger.SelectedRows[0].Cells[4].Value.ToString();
            PassGend.SelectedItem = ViewPassenger.SelectedRows[0].Cells[5].Value.ToString();


        }

       
    }
}
