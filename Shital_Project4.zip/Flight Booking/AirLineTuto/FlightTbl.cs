﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AirLineTuto
{
    public partial class FlightTbl : Form
    {
        public FlightTbl()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=AirlineDb;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
        private void button3_Click(object sender, EventArgs e)
        {
            Home ob = new Home();
            ob.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Fcode.Text == "" || Fsrc.Text == "" || FDest.Text == "" || FDate.Text == "" || Seatnum.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "insert into FlightTbl values('" + Fcode.Text + "','" + Fsrc.SelectedItem.ToString() + "','" + FDest.SelectedItem.ToString() + "','" + FDate.Value.ToString() + "','" + Seatnum.Text + "');";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Insert record Successfully");
                    conn.Close();
                }
                catch (Exception ob)
                {
                    MessageBox.Show(ob.Message);
                }

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Fcode.Text = "";
            Fsrc.Text = "";
            FDest.Text = "";
            FDate.Text = "";
            Seatnum.Text = "";
            

        }

        private void FlightTbl_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            ViewFlight ob = new ViewFlight();
            ob.Show();
            this.Hide();
        }
    }
}
