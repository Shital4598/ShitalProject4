﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AirLineTuto
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(Uidtxt.Text==""|| Pswdtxt.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else if(Uidtxt.Text=="Admin" && Pswdtxt.Text == "Admin")
            {
                Home ob = new Home();
                ob.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Wrong User Id or Password");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Uidtxt.Text = "";
            Pswdtxt.Text = "";
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
