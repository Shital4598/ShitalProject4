﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace AirLineTuto
{
    public partial class Signup : Form
    {
        public Signup()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=(localdb)\ProjectsV13;Initial Catalog=SIGNUP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

        private void Signup_Load(object sender, EventArgs e)
        {
            dt = GetTable("select * from SIGNTBL");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (usertxt.Text == "" || pwdtxt.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    conn.Open();
                    string query = "insert into SIGNTBL values('" + usertxt.Text + "','" + pwdtxt.Text + "');";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Sign Up Successfully");
                    conn.Close();
                }
                catch (Exception ob)
                {
                    MessageBox.Show(ob.Message);
                }



            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            usertxt.Text = "";
            pwdtxt.Text = "";
            
        }
        DataTable dt;
        SqlDataAdapter da;
        public DataTable GetTable(string query)
        {
            da = new SqlDataAdapter(query, conn);
            dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dt = GetTable("select * from SIGNTBL where USERNAME='" + usertxt.Text + "' and PASSWORD='" + pwdtxt.Text + "'");
            if (dt.Rows.Count == 1)
            {
                MessageBox.Show("login successful");
                Home ob = new Home();
                ob.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("invalid username or password");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

       
    }
}
